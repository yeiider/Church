<?php
echo 'La fecha '.$_POST['date'].' se ha guardado correctamente!';
?>
