<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
	<title>Datepicker Jquery</title>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<link type="text/css" href="css/ui-darkness/jquery-ui-1.8.23.custom.css" rel="Stylesheet" />
	<script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.23.custom.min.js"></script>
        <script type="text/javascript" src="js/jquery.ui.datepicker-es.js"></script>
	<script type="text/javascript">
	$(function() {
		$("#datepicker").datepicker();
		$("#format").change(function() { $('#datepicker').datepicker('option', {dateFormat: $(this).val()}); });
	});
	</script>
</head>
<body>
<?php
if (isset($_POST['nuevafecha'])) {
	if (isset($_POST['fecha']) && $_POST['fecha'] != '') {
		echo 'Fecha recibida: '.$_POST['fecha'].'<br>';
		$partes = explode('/', $_POST['fecha']);
		$fecha = $partes[2].'-'.$partes[0].'-'.$partes[1];
		echo 'Fecha formateda para meter en base de datos: '.$fecha.'<br><br>';
	}
	else {
		echo 'La fecha introducida no es correcta.<br><br>';
	}
}
?>
<form action="index.php" method="POST"/>
	<div class="demo">
		Selecciona fecha: <input id="datepicker" type="text" name="fecha">
		<input type="submit" name="nuevafecha" value="Enviar"/>
	</div>
</form>
<div style="float:left; width:100%; margin-top:20px;">
    	<iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FBlog-Jose-Aguilar-Desarrollo-Web%2F269898786396364&send=false&layout=standard&width=450&show_faces=false&font=lucida+grande&colorscheme=light&action=like&height=35&appId=283652475068166" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:35px;" allowTransparency="true"></iframe>
    </div>
</body>
</html>